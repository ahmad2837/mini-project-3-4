# Product Explorer (MP3 + MP4)

Course: Software Development I (CSE-2340), IIUC
A simple API-driven web app built with HTML, CSS and JavaScript only.

## What it does
- Loads products from the free **DummyJSON API** (`https://dummyjson.com/products`)
- Search by name, filter by category, sort by price or rating
- Save favorite products with a button; favorites stay after refreshing the page
- "Show Favorites" button displays only the saved products

## How to run
Open `index.html` in any browser (internet connection needed for the API).

## Folder structure
```
product-explorer/
├── index.html
├── css/style.css
├── js/script.js
└── README.md
```

## Requirement checklist (where to find it in the code)

| Requirement | Where in `js/script.js` |
|---|---|
| DOM selectors and dynamic rendering | Section 1 (`querySelector`), Section 7 (`displayProducts`, `createElement`, `appendChild`) |
| Searching / filtering / selecting | Section 6 (`getVisibleProducts`) |
| `addEventListener()` | Section 9 |
| Arrays and `map()`, `filter()`, `forEach()`, `includes()`, `sort()` | Sections 5, 6, 7, 8 |
| `fetch()` + `async/await` | Section 3 (`fetchProducts`) |
| Loading, error and empty states | Section 4, plus the `#loading`, `#error`, `#empty` boxes in `index.html` |
| Local Storage | Section 8 (`localStorage.setItem` / `getItem`) |
